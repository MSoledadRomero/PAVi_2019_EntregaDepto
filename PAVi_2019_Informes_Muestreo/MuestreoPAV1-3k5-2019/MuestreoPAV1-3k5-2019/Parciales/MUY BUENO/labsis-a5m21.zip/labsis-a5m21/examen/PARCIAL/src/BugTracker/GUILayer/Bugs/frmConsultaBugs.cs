﻿using BugTracker.BusinessLayer;
using BugTracker.Entities;
using BugTracker.GUILayer;
using BugTracker.GUILayer.Bugs;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BugTracker.GUILayer
{
    public partial class frmConsultaBugs : Form
    {
        private readonly BugService bugService;
        private readonly ProductoService proService;


        public frmConsultaBugs()
        {
            InitializeComponent();
            // Inicializamos la grilla de bugs
            InitializeDataGridView();
            bugService = new BugService();
            proService = new ProductoService();
            
        }

        private void frmBugs_Load(object sender, EventArgs e)
        {
            LlenarCombo(cboProducto, proService.ObtenerTodos(), "Nombre", "IdProducto");
            dgvBugs.Rows.Clear();
            //Completar
        }

        private void btnConsultar_Click(object sender, EventArgs e)
        {
            if (cboProducto.SelectedIndex == -1)
            {
                MessageBox.Show("Por favor seleccione un producto..", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }else{
                var parametros = new Dictionary<string, object>();
                int idProducto = (int)cboProducto.SelectedValue;
                parametros.Add("id_producto", idProducto);
                IList<Bug> listBug = bugService.ConsultarBugsConFiltros(parametros);
                dgvBugs.DataSource = listBug;
                if (listBug.Count == 0)
                {
                    MessageBox.Show("No se encontraron registros en la BD", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                
            }
        }

        private void LlenarCombo(ComboBox cbo, Object source, string display, String value)
        {
            // Datasource: establece el origen de datos de este objeto.
            cbo.DataSource = source;
            // DisplayMember: establece la propiedad que se va a mostrar para este ListControl.
            cbo.DisplayMember = display;
            // ValueMember: establece la ruta de acceso de la propiedad que se utilizará como valor real para los elementos de ListControl.
            cbo.ValueMember = value;
            //SelectedIndex: establece el índice que especifica el elemento seleccionado actualmente.
            cbo.SelectedIndex = -1;
        }


        private void InitializeDataGridView()
        {
            // Cree un DataGridView no vinculado declarando un recuento de columnas.
            dgvBugs.ColumnCount = 10;
            dgvBugs.ColumnHeadersVisible = true;

            // Configuramos la AutoGenerateColumns en false para que no se autogeneren las columnas
            dgvBugs.AutoGenerateColumns = false;

            // Cambia el estilo de la cabecera de la grilla.
            DataGridViewCellStyle columnHeaderStyle = new DataGridViewCellStyle();

            columnHeaderStyle.BackColor = Color.Beige;
            columnHeaderStyle.Font = new Font("Verdana", 8, FontStyle.Bold);
            dgvBugs.ColumnHeadersDefaultCellStyle = columnHeaderStyle;

            // Definimos el nombre de la columnas y el DataPropertyName que se asocia a DataSource
            dgvBugs.Columns[0].Name = "ID";
            dgvBugs.Columns[0].DataPropertyName = "idBug";
            // Definimos el ancho de la columna.
            dgvBugs.Columns[0].Width = 50;

            dgvBugs.Columns[1].Name = "Título";
            dgvBugs.Columns[1].DataPropertyName = "titulo";

            dgvBugs.Columns[2].Name = "Descripción";
            dgvBugs.Columns[2].DataPropertyName = "descripcion";

            dgvBugs.Columns[3].Name = "Responsable";
            dgvBugs.Columns[3].DataPropertyName = "UsuarioResponsable";

            dgvBugs.Columns[4].Name = "Asignado";
            dgvBugs.Columns[4].DataPropertyName = "UsuarioAsignado";

            dgvBugs.Columns[5].Name = "Prioridad";
            dgvBugs.Columns[5].DataPropertyName = "prioridad";

            dgvBugs.Columns[6].Name = "Criticidad";
            dgvBugs.Columns[6].DataPropertyName = "criticidad";

            dgvBugs.Columns[7].Name = "Producto";
            dgvBugs.Columns[7].DataPropertyName = "producto";

            dgvBugs.Columns[8].Name = "Fecha Alta";
            dgvBugs.Columns[8].DataPropertyName = "fechaAlta";

            dgvBugs.Columns[9].Name = "Estado";
            dgvBugs.Columns[9].DataPropertyName = "Estado";

            // Cambia el tamaño de la altura de los encabezados de columna.
            dgvBugs.AutoResizeColumnHeadersHeight();

            // Cambia el tamaño de todas las alturas de fila para ajustar el contenido de todas las celdas que no sean de encabezado.
            dgvBugs.AutoResizeRows(
                DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders);
        }


        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvBugs_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (dgvBugs.CurrentRow != null)
            {
                frmABMBug frmDetalleBug = new frmABMBug();
                var bugseleccionado = (Bug)dgvBugs.CurrentRow.DataBoundItem;
                frmDetalleBug.SeleccionarBug(bugseleccionado);
                frmDetalleBug.ShowDialog();

            }
        }




    }



}
