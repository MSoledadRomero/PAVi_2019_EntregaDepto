﻿using BugTracker.BusinessLayer;
using BugTracker.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace BugTracker.GUILayer.Bugs
{
    public partial class frmABMBug : Form
    {

        private PrioridadService prioridadService;
        private ProductoService productoService;
        private CriticidadService criticidadService;

        private Bug oBugSeleccionado;
        private BugService oBugService;

        public frmABMBug()
        {
            InitializeComponent();

            oBugService = new BugService();
            criticidadService = new CriticidadService();
            productoService = new ProductoService();
            prioridadService = new PrioridadService();
        }

        private void FrmABMBug_Load(object sender, EventArgs e)
        {            
            //Completar
            //LLenar combos y limpiar grilla
            LlenarCombo(cboProducto, productoService.ObtenerTodos(), "Nombre", "IdProducto");
            LlenarCombo(cboPrioridad, prioridadService.ObtenerTodos(), "Nombre", "IdPrioridad");
            LlenarCombo(cboCriticidad, criticidadService.ObtenerTodos(), "Nombre", "IdCriticidad");
            txtTitulo.Text = oBugSeleccionado.Titulo;
            txtDescripcion.Text = oBugSeleccionado.Descripcion;
            cboProducto.Text = oBugSeleccionado.Producto.Nombre;
            cboCriticidad.Text = oBugSeleccionado.Criticidad.Nombre;
            cboPrioridad.Text = oBugSeleccionado.Prioridad.Nombre;
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            if (Validaciones())
            {
                var respuesta = MessageBox.Show("Está seguro de actualizar el bug y generar su historial?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (respuesta == DialogResult.Yes)
                {
                    Bug oBug = new Bug();
                    oBug.UsuarioResponsable = oBugSeleccionado.UsuarioResponsable;
                    oBug.UsuarioAsignado = oBugSeleccionado.UsuarioAsignado;
                    oBug.IdBug = oBugSeleccionado.IdBug;
                    oBug.Estado = oBugSeleccionado.Estado;

                    oBug.Titulo = txtTitulo.Text;
                    oBug.Descripcion = txtDescripcion.Text;

                    Producto producto = new Producto();
                    producto.IdProducto = (int)cboProducto.SelectedValue;
                    producto.Nombre = cboProducto.Text;
                    oBug.Producto = producto;

                    Criticidad criticidad = new Criticidad();
                    criticidad.IdCriticidad = (int)cboCriticidad.SelectedValue;
                    criticidad.Nombre = cboCriticidad.Text;
                    oBug.Criticidad = criticidad;

                    Prioridad prioridad = new Prioridad();
                    prioridad.IdPrioridad = (int)cboPrioridad.SelectedValue;
                    prioridad.Nombre = cboPrioridad.Text;
                    oBug.Prioridad = prioridad;

                    
                    bool resultado = oBugService.updateBugconHistorial(oBug);
                    if (resultado)
                    {
                        MessageBox.Show("El bug se registro con éxito, y se genero su historial", "Confirmación", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Error al registrar Bug", "Confirmación", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private bool Validaciones()
        {
            if (String.IsNullOrEmpty(txtTitulo.Text))
            {
                MessageBox.Show("El titulo no puede estar vacío..", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }else if(cboProducto.SelectedIndex==-1){
                MessageBox.Show("Por favor seleccione un producto..", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            return true;

        }
        private void LlenarCombo(ComboBox cbo, Object source, string display, String value)
        {
            cbo.DataSource = source;
            cbo.DisplayMember = display;
            cbo.ValueMember = value;
            cbo.SelectedIndex = -1;
        }

        
        public void SeleccionarBug(Bug bugSelected)
        {
            oBugSeleccionado = bugSelected;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

}
