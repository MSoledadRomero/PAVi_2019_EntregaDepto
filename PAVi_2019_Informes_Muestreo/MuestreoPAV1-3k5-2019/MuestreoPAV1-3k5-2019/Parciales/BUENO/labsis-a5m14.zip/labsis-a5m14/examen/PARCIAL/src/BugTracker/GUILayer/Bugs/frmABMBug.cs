﻿using BugTracker.BusinessLayer;
using BugTracker.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace BugTracker.GUILayer.Bugs
{
    public partial class frmABMBug : Form
    {

        private PrioridadService prioridadService;
        private ProductoService productoService;
        private CriticidadService criticidadService;

        private Bug oBugSeleccionado;
        private BugService oBugService;

        public frmABMBug()
        {
            InitializeComponent();

            oBugService = new BugService();
            criticidadService = new CriticidadService();
            productoService = new ProductoService();
            prioridadService = new PrioridadService();

        }

        private void FrmABMBug_Load(object sender, EventArgs e)
        {            
            //Completar
            //LLenar combos y limpiar grilla
            LlenarCombo(cboCriticidad, criticidadService.ObtenerTodos(), "id_criticidad", "nombre");
            LlenarCombo(cboProducto, productoService.ObtenerTodos(), "id_producto", "nombre");
            LlenarCombo(cboPrioridad, prioridadService.ObtenerTodos(), "id_´prioridad", "nombre");
            txtTitulo.Text = oBugSeleccionado.Titulo;
            txtDescripcion.Text = oBugSeleccionado.Descripcion;
            cboProducto.Text = oBugSeleccionado.Producto.ToString();
            cboCriticidad.Text = oBugSeleccionado.Criticidad.ToString();
            cboPrioridad.Text = oBugSeleccionado.Prioridad.ToString();

        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            //Completar
            if (txtTitulo.Text == "")
            {
                MessageBox.Show("Debe ingresar un título", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            if (cboProducto.Text == "")
            {
                MessageBox.Show("Debe seleccionar un producto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                DialogResult answer = MessageBox.Show("Está seguro de actualizar el bug y generar su historial?", "Atención", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                if (answer == DialogResult.Yes)
                {
                    if(oBugService.updateBugconHistorial(oBugSeleccionado)){
                        MessageBox.Show("Bug guardado con éxito", "Atención", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    else{
                        MessageBox.Show("No se pudo guardar el bug", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
            }

        }   
        private void LlenarCombo(ComboBox cbo, Object source, string display, String value)
        {
            cbo.DataSource = source;
            cbo.DisplayMember = display;
            cbo.ValueMember = value;
            cbo.SelectedIndex = -1;
        }

        
        public void SeleccionarBug(Bug bugSelected)
        {
            oBugSeleccionado = bugSelected;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }

}
