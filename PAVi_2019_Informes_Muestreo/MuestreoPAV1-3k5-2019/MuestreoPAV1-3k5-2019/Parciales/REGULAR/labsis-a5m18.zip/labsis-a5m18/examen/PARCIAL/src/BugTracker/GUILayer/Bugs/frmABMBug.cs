﻿using BugTracker.BusinessLayer;
using BugTracker.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace BugTracker.GUILayer.Bugs
{
    public partial class frmABMBug : Form
    {

        private PrioridadService prioridadService;
        private ProductoService productoService;
        private CriticidadService criticidadService;

        private Bug oBugSeleccionado;
        private BugService oBugService;

        public frmABMBug()
        {
            InitializeComponent();

            oBugService = new BugService();
            criticidadService = new CriticidadService();
            productoService = new ProductoService();
            prioridadService = new PrioridadService();

        }

        private void FrmABMBug_Load(object sender, EventArgs e)
        {            
            //Completar
            //LLenar combos y limpiar grilla

        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            //Completar
        }

              
        private void LlenarCombo(ComboBox cbo, Object source, string display, String value)
        {
            cbo.DataSource = source;
            cbo.DisplayMember = display;
            cbo.ValueMember = value;
            cbo.SelectedIndex = -1;
        }

        
        public void SeleccionarBug(Bug bugSelected)
        {
            oBugSeleccionado = bugSelected;
        }


    }

}
