﻿using BugTracker.BusinessLayer;
using BugTracker.Entities;
using BugTracker.GUILayer;
using BugTracker.GUILayer.Bugs;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using BugTracker.Entities;


namespace BugTracker.GUILayer
{
    public partial class frmConsultaBugs : Form
    {
        private readonly BugService bugService;
        private readonly ProductoService proService;
        
        string cadenaConexion {get; set;}

        public frmConsultaBugs()
        {
            InitializeComponent();
            InitializeDataGridView();
            // Inicializamos la grilla de bugs
            InitializeDataGridView();
            bugService = new BugService();
            proService = new ProductoService();
            cadenaConexion = "Data Source=MAQUIS;Initial Catalog=BugTracker_66899;User ID=avisuales1;Password=avisuales1";

            
            //cargarCombo(ref cboProducto, "Productos", "nombre", "id_producto");
        }

        private void frmBugs_Load(object sender, EventArgs e)
        {
            cargarCombo(ref cboProducto, "Productos", "nombre", "id_producto");
            //LLenar combos y limpiar grid
            //Completar
        }

        private void cargarCombo(ref ComboBox combo, string nomtabla, string nombre, string id)
    
    {
        SqlConnection conexion = new SqlConnection(cadenaConexion);
        SqlCommand cmd = new SqlCommand();

        string consulta = "SELECT * FROM " + nomtabla;
        cmd.Parameters.Clear();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = consulta;

        DataTable tabla = new DataTable();

        cmd.Connection = conexion;
        conexion.Open();

        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(tabla);

        cmd.ExecuteNonQuery();

        combo.DataSource = tabla;
        combo.DisplayMember = nombre;
        combo.ValueMember = id;

        conexion.Close();


    }

        private void cargarGrilla(int valorid)
        {
            SqlConnection conexion = new SqlConnection(cadenaConexion);
            SqlCommand cmd = new SqlCommand();



            string consulta = "SELECT * FROM Bugs WHERE id_producto = " + valorid;
            cmd.Parameters.Clear();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = consulta;

            DataTable tabla = new DataTable();

            cmd.Connection = conexion;
            conexion.Open();

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(tabla);

            cmd.ExecuteNonQuery();


            dgvBugs.DataSource = tabla;

            conexion.Close();


        }

     






        private void btnConsultar_Click(object sender, EventArgs e)
        {   int elegido = 9; 
            string opcion = cboProducto.SelectedValue.ToString();
            if( opcion == "Software de Gestión" ) {elegido = 1;};
            if( opcion == "Soft. de Gestión de Identidad" ) {elegido = 2;};
            if( opcion == "Software de Auditoría" ) {elegido = 3;};
            if (opcion == "Soft. Vulnerabilidades") { elegido = 4; };
            
            GetBugById(elegido);
            //cargarGrilla(int.Parse(cboProducto.SelectedValue.ToString()));
            //Completar
            
        }

        private void LlenarCombo(ComboBox cbo, Object source, string display, String value)
        {
            // Datasource: establece el origen de datos de este objeto.
            cbo.DataSource = source;
            // DisplayMember: establece la propiedad que se va a mostrar para este ListControl.
            cbo.DisplayMember = display;
            // ValueMember: establece la ruta de acceso de la propiedad que se utilizará como valor real para los elementos de ListControl.
            cbo.ValueMember = value;
            //SelectedIndex: establece el índice que especifica el elemento seleccionado actualmente.
            cbo.SelectedIndex = -1;
        }


        private void InitializeDataGridView()
        {
            // Cree un DataGridView no vinculado declarando un recuento de columnas.
            dgvBugs.ColumnCount = 10;
            dgvBugs.ColumnHeadersVisible = true;

            // Configuramos la AutoGenerateColumns en false para que no se autogeneren las columnas
            dgvBugs.AutoGenerateColumns = false;

            // Cambia el estilo de la cabecera de la grilla.
            DataGridViewCellStyle columnHeaderStyle = new DataGridViewCellStyle();

            columnHeaderStyle.BackColor = Color.Beige;
            columnHeaderStyle.Font = new Font("Verdana", 8, FontStyle.Bold);
            dgvBugs.ColumnHeadersDefaultCellStyle = columnHeaderStyle;

            // Definimos el nombre de la columnas y el DataPropertyName que se asocia a DataSource
            dgvBugs.Columns[0].Name = "ID";
            dgvBugs.Columns[0].DataPropertyName = "idBug";
            // Definimos el ancho de la columna.
            dgvBugs.Columns[0].Width = 50;

            dgvBugs.Columns[1].Name = "Título";
            dgvBugs.Columns[1].DataPropertyName = "titulo";

            dgvBugs.Columns[2].Name = "Descripción";
            dgvBugs.Columns[2].DataPropertyName = "descripcion";

            dgvBugs.Columns[3].Name = "Responsable";
            dgvBugs.Columns[3].DataPropertyName = "UsuarioResponsable";

            dgvBugs.Columns[4].Name = "Asignado";
            dgvBugs.Columns[4].DataPropertyName = "UsuarioAsignado";

            dgvBugs.Columns[5].Name = "Prioridad";
            dgvBugs.Columns[5].DataPropertyName = "prioridad";

            dgvBugs.Columns[6].Name = "Criticidad";
            dgvBugs.Columns[6].DataPropertyName = "criticidad";

            dgvBugs.Columns[7].Name = "Producto";
            dgvBugs.Columns[7].DataPropertyName = "producto";

            dgvBugs.Columns[8].Name = "Fecha Alta";
            dgvBugs.Columns[8].DataPropertyName = "fechaAlta";

            dgvBugs.Columns[9].Name = "Estado";
            dgvBugs.Columns[9].DataPropertyName = "Estado";

            // Cambia el tamaño de la altura de los encabezados de columna.
            dgvBugs.AutoResizeColumnHeadersHeight();

            // Cambia el tamaño de todas las alturas de fila para ajustar el contenido de todas las celdas que no sean de encabezado.
            dgvBugs.AutoResizeRows(
                DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders);
        }


        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvBugs_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (dgvBugs.CurrentRow != null)
            {
                frmABMBug frmDetalleBug = new frmABMBug();
                var bugseleccionado = (Bug)dgvBugs.CurrentRow.DataBoundItem;
                frmDetalleBug.SeleccionarBug(bugseleccionado);
                frmDetalleBug.ShowDialog();

            }
        }

        private void cboProducto_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        public Bug GetBugById(int idBug)
        {
            var strSql = String.Concat("SELECT bug.id_bug, ",
                                      "        bug.titulo,",
                                      "        bug.descripcion,",
                                      "        bug.fecha_alta,",
                                      "        bug.id_usuario_responsable,",
                                      "        responsable.usuario as responsable,  ",
                                      "        bug.id_usuario_asignado,",
                                      "        asignado.usuario as asignado, ",
                                      "        bug.id_producto,",
                                      "        producto.nombre as producto, ",
                                      "        bug.id_prioridad,",
                                      "        prioridad.nombre as prioridad, ",
                                      "        bug.id_criticidad,",
                                      "        criticidad.nombre as criticidad, ",
                                      "        bug.id_estado,",
                                      "        estado.nombre as estado",
                                       "   FROM Bugs as bug",
                                       "   LEFT JOIN Usuarios as responsable ON responsable.id_usuario = bug.id_usuario_responsable",
                                       "   LEFT JOIN Usuarios as asignado ON asignado.id_usuario = bug.id_usuario_asignado",
                                       "  INNER JOIN Productos as producto ON producto.id_producto = bug.id_producto",
                                       "  INNER JOIN Prioridades as prioridad ON  prioridad.id_prioridad = bug.id_prioridad",
                                       "  INNER JOIN Criticidades as criticidad ON criticidad.id_criticidad = bug.id_criticidad",
                                       "  INNER JOIN Estados as estado ON estado.id_estado = bug.id_estado",
                                       "  WHERE bug.borrado=0 AND bug.id_bug = " + idBug.ToString());

            return MappingBug(DataAccessLayer.DataManager.GetInstance().ConsultaSQL(strSql).Rows[0]);
        }
        private Bug MappingBug(DataRow row)
        {
            Bug oBug = new Bug();
            oBug.IdBug = Convert.ToInt32(row["id_bug"].ToString());
            oBug.Titulo = row["titulo"].ToString();
            oBug.Descripcion = row["descripcion"].ToString();
            oBug.FechaAlta = Convert.ToDateTime(row["fecha_alta"].ToString());
            oBug.Producto = new Producto();
            oBug.Producto.IdProducto = Convert.ToInt32(row["id_producto"].ToString());
            oBug.Producto.Nombre = row["producto"].ToString();

            oBug.Prioridad = new Prioridad();
            oBug.Prioridad.IdPrioridad = Convert.ToInt32(row["id_prioridad"].ToString());
            oBug.Prioridad.Nombre = row["prioridad"].ToString();

            oBug.Criticidad = new Criticidad();
            oBug.Criticidad.IdCriticidad = Convert.ToInt32(row["id_criticidad"].ToString());
            oBug.Criticidad.Nombre = row["criticidad"].ToString();


            oBug.Estado = new Estado();
            oBug.Estado.IdEstado = Convert.ToInt32(row["id_estado"].ToString());
            oBug.Estado.Nombre = row["estado"].ToString();

            oBug.UsuarioResponsable = new Usuario();
            oBug.UsuarioResponsable.IdUsuario = Convert.ToInt32(row["id_usuario_responsable"].ToString());
            oBug.UsuarioResponsable.NombreUsuario = row["responsable"].ToString();

            oBug.UsuarioAsignado = new Usuario();
            oBug.UsuarioAsignado.IdUsuario = Convert.ToInt32(row["id_usuario_asignado"].ToString());
            oBug.UsuarioAsignado.NombreUsuario = row["asignado"].ToString();

            return oBug;
        }

    }



}
